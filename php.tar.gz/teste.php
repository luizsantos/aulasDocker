<?
  php phpinfo(); 
?>
